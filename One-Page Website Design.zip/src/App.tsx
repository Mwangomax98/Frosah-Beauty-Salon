import { useState } from "react";

// ── Image helper ────────────────────────────────────────────
function img(id: string, w: number, h: number) {
  return `https://images.unsplash.com/photo-${id}?w=${w}&h=${h}&fit=crop&auto=format`;
}

// ── Vanity Bulbs (signature motif) ───────────────────────────
function VanityBulbs({ count = 9, className = "" }: { count?: number; className?: string }) {
  const center = Math.floor(count / 2);
  return (
    <div className={`flex items-center justify-center gap-2 ${className}`}>
      {Array.from({ length: count }).map((_, i) => {
        const dist = Math.abs(i - center);
        const size = dist === 0 ? 14 : dist === 1 ? 11 : 9;
        const opacity = Math.max(0.4, 1 - dist * 0.15);
        const glow =
          dist === 0
            ? "0 0 16px 5px rgba(201,151,58,0.55)"
            : dist === 1
            ? "0 0 9px 3px rgba(201,151,58,0.35)"
            : "0 0 5px 1px rgba(201,151,58,0.2)";
        return (
          <span
            key={i}
            style={{ display: "block", width: size, height: size, borderRadius: "50%", background: "#C9973A", boxShadow: glow, opacity }}
          />
        );
      })}
    </div>
  );
}

// ── Star rating ──────────────────────────────────────────────
function Stars({ n = 5 }: { n?: number }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: n }).map((_, i) => (
        <span key={i} className="text-gold text-sm">★</span>
      ))}
    </div>
  );
}

// ── Nav ──────────────────────────────────────────────────────
function Nav() {
  const [open, setOpen] = useState(false);
  const links = [
    { label: "Services", href: "#services" },
    { label: "About", href: "#about" },
    { label: "Gallery", href: "#gallery" },
  ];
  return (
    <header className="sticky top-0 z-50 bg-plum/95 backdrop-blur-md border-b border-white/10">
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        {/* Logo */}
        <a href="#" className="flex items-center gap-2.5">
          <span className="flex gap-1 items-center">
            {[10, 13, 10].map((s, i) => (
              <span key={i} style={{ display: "block", width: s, height: s, borderRadius: "50%", background: "#C9973A", boxShadow: "0 0 8px 2px rgba(201,151,58,0.5)" }} />
            ))}
          </span>
          <span style={{ fontFamily: "var(--font-serif)" }} className="text-xl text-white tracking-wide leading-none">
            Friday<span className="text-gold italic"> Beauty</span>
          </span>
        </a>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-8">
          {links.map((l) => (
            <a key={l.label} href={l.href} className="text-white/75 hover:text-white text-sm font-medium transition-colors">
              {l.label}
            </a>
          ))}
          <a href="#booking" className="bg-gold text-ink text-sm font-semibold px-5 py-2.5 rounded-full hover:bg-gold-light transition-colors">
            Book Now
          </a>
        </nav>

        {/* Mobile hamburger */}
        <button className="md:hidden text-white p-2" onClick={() => setOpen(!open)} aria-label="Menu">
          <svg width="22" height="22" fill="none" stroke="currentColor" strokeWidth={2}>
            {open ? (
              <>
                <line x1="4" y1="4" x2="18" y2="18" />
                <line x1="18" y1="4" x2="4" y2="18" />
              </>
            ) : (
              <>
                <line x1="3" y1="7" x2="21" y2="7" />
                <line x1="3" y1="12" x2="21" y2="12" />
                <line x1="3" y1="17" x2="21" y2="17" />
              </>
            )}
          </svg>
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden bg-plum border-t border-white/10 px-6 py-4 flex flex-col gap-4">
          {links.map((l) => (
            <a key={l.label} href={l.href} onClick={() => setOpen(false)} className="text-white/80 hover:text-white font-medium">
              {l.label}
            </a>
          ))}
          <a href="#booking" onClick={() => setOpen(false)} className="bg-gold text-ink font-semibold px-5 py-3 rounded-full text-center">
            Book Now
          </a>
        </div>
      )}
    </header>
  );
}

// ── Hero ─────────────────────────────────────────────────────
function HeroSection() {
  return (
    <section id="hero" className="relative overflow-hidden min-h-screen bg-cream" style={{ minHeight: "92vh" }}>
      <div className="grid lg:grid-cols-2 min-h-[92vh]">
        {/* Left content */}
        <div className="flex flex-col justify-center px-8 sm:px-14 xl:px-20 py-24 relative z-10">
          {/* Eyebrow */}
          <div className="flex items-center gap-2 mb-5">
            <span className="w-8 h-px bg-gold" />
            <span className="text-xs font-semibold tracking-widest uppercase text-berry">Tanga, Tanzania</span>
          </div>

          {/* Headline */}
          <h1 style={{ fontFamily: "var(--font-serif)" }} className="text-5xl sm:text-6xl xl:text-7xl text-ink leading-[1.08] mb-6">
            Your Hair,<br />
            <span className="text-berry italic">Your Crown.</span>
          </h1>

          {/* Subtext */}
          <p className="text-ink/65 text-lg max-w-md leading-relaxed mb-10">
            Premium wig sales, flawless installs, bespoke customization, and braiding artistry — all under one roof.
          </p>

          {/* CTAs */}
          <div className="flex flex-wrap items-center gap-4 mb-14">
            <a
              href="#booking"
              className="bg-plum text-white font-semibold px-8 py-4 rounded-full hover:bg-berry transition-colors shadow-lg shadow-plum/30"
            >
              Book Now
            </a>
            <a href="#services" className="text-plum font-semibold flex items-center gap-2 hover:text-berry transition-colors group">
              See Services
              <span className="group-hover:translate-x-1 transition-transform">→</span>
            </a>
          </div>

          {/* Bottom vanity accent */}
          <VanityBulbs count={7} />
        </div>

        {/* Right photo */}
        <div className="relative min-h-[55vw] lg:min-h-0 bg-blush-dark overflow-visible">
          <img
            src={img("1762745103248-093916cce084", 900, 1100)}
            alt="Model with sleek styled hair"
            className="w-full h-full object-cover object-top absolute inset-0"
          />
          {/* Gradient overlay on left edge so it blends with content */}
          <div className="absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-cream to-transparent lg:block hidden" />

          {/* Trust badge 1 */}
          <div
            className="float-badge absolute top-12 left-0 lg:-left-6 z-20 bg-white rounded-2xl px-5 py-3 shadow-xl border border-gold/20 flex items-center gap-3"
          >
            <span className="w-9 h-9 rounded-full bg-gold/15 flex items-center justify-center text-gold text-lg">⚡</span>
            <div>
              <p className="text-xs text-ink/50 font-medium uppercase tracking-wide">Service</p>
              <p className="font-semibold text-ink text-sm">Same-Day Install</p>
            </div>
          </div>

          {/* Trust badge 2 */}
          <div
            className="float-badge-delayed absolute bottom-20 left-0 lg:-left-8 z-20 bg-plum rounded-2xl px-5 py-3 shadow-xl flex items-center gap-3"
          >
            <span className="w-9 h-9 rounded-full bg-white/15 flex items-center justify-center text-gold text-lg">✦</span>
            <div>
              <p className="text-xs text-white/60 font-medium uppercase tracking-wide">Quality</p>
              <p className="font-semibold text-white text-sm">100% Human Hair</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ── Marquee Strip ─────────────────────────────────────────────
function MarqueeStrip() {
  const items = ["Wig Sales", "Installation", "Customization", "Revamping", "Braiding"];
  const doubled = [...items, ...items, ...items, ...items];
  return (
    <div className="bg-berry py-4 overflow-hidden">
      <div className="marquee-inner select-none">
        {doubled.map((item, i) => (
          <span key={i} className="flex items-center gap-4 px-6">
            <span className="text-white font-medium text-sm tracking-wide whitespace-nowrap">{item}</span>
            <span className="text-gold text-lg flex-shrink-0">✦</span>
          </span>
        ))}
      </div>
    </div>
  );
}

// ── Service Categories ─────────────────────────────────────────
function ServiceCategories() {
  const services = [
    { name: "Wig Sales", img: "1729106719547-2c6f565313ba", desc: "Premium human hair wigs" },
    { name: "Installation", img: "1761839256791-6a93f89fb8b0", desc: "Flawless lace-front installs" },
    { name: "Customization", img: "1762745103094-6760fab8eb50", desc: "Cut, bleach, tint & style" },
    { name: "Revamping", img: "1572955304332-bf714bd49add", desc: "Restore & refresh any wig" },
    { name: "Braiding", img: "1527203561188-dae1bc1a417f", desc: "Box braids, knotless & more" },
  ];

  return (
    <section id="services" className="bg-cream py-24 px-6">
      <div className="max-w-6xl mx-auto">
        {/* Eyebrow */}
        <div className="flex items-center gap-3 justify-center mb-3">
          <span className="w-8 h-px bg-gold" />
          <span className="text-xs font-semibold tracking-widest uppercase text-berry">What We Do</span>
          <span className="w-8 h-px bg-gold" />
        </div>
        <h2 style={{ fontFamily: "var(--font-serif)" }} className="text-4xl sm:text-5xl text-ink text-center mb-4">
          Our Services
        </h2>
        <p className="text-ink/55 text-center max-w-md mx-auto mb-16">
          From a brand-new unit to a full revamp — we handle every strand with care.
        </p>

        <div className="flex flex-wrap gap-10 justify-center">
          {services.map((s) => (
            <a
              key={s.name}
              href="#booking"
              className="flex flex-col items-center gap-4 group cursor-pointer"
            >
              <div
                className="w-28 h-28 rounded-full overflow-hidden border-4 border-transparent group-hover:border-gold transition-all duration-300 shadow-lg group-hover:shadow-gold/30 group-hover:shadow-xl bg-blush"
              >
                <img
                  src={img(s.img, 200, 200)}
                  alt={s.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
              </div>
              <div className="text-center">
                <p className="font-semibold text-ink text-sm">{s.name}</p>
                <p className="text-ink/50 text-xs mt-0.5">{s.desc}</p>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

// ── Featured Deals ─────────────────────────────────────────────
function FeaturedDeals() {
  const deals = [
    {
      tag: "New Client Offer",
      title: "20% Off Your First Install",
      desc: "Walk in as a stranger, leave as a regular. Applies to all lace-front and glueless installs for first-time clients.",
      cta: "Claim Offer",
      img: "1761373564177-8505a38c91f2",
      badge: "−20%",
      badgeBg: "bg-gold",
    },
    {
      tag: "Limited Time",
      title: "Braid Touch-Up Special",
      desc: "Keep your braids fresh. Bring in any style done within 4 weeks and we will tighten, re-do edges, and moisturize at half the re-do price.",
      cta: "Book a Touch-Up",
      img: "1763048208932-cbe149724374",
      badge: "50% Off",
      badgeBg: "bg-berry",
    },
  ];

  return (
    <section className="bg-blush py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-3 justify-center mb-3">
          <span className="w-8 h-px bg-gold" />
          <span className="text-xs font-semibold tracking-widest uppercase text-berry">Current Deals</span>
          <span className="w-8 h-px bg-gold" />
        </div>
        <h2 style={{ fontFamily: "var(--font-serif)" }} className="text-4xl sm:text-5xl text-ink text-center mb-16">
          Featured Offers
        </h2>

        <div className="grid md:grid-cols-2 gap-8">
          {deals.map((d) => (
            <div key={d.title} className="bg-white rounded-3xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow group">
              <div className="relative h-64 overflow-hidden bg-blush-dark">
                <img
                  src={img(d.img, 800, 500)}
                  alt={d.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <span className={`${d.badgeBg} text-white font-bold text-sm px-4 py-2 rounded-full absolute top-4 right-4 shadow`}>
                  {d.badge}
                </span>
                <span className="bg-black/40 text-white text-xs font-semibold tracking-widest uppercase px-3 py-1 rounded-full absolute top-4 left-4 backdrop-blur-sm">
                  {d.tag}
                </span>
              </div>
              <div className="p-8">
                <h3 style={{ fontFamily: "var(--font-serif)" }} className="text-2xl text-ink mb-3">{d.title}</h3>
                <p className="text-ink/60 text-sm leading-relaxed mb-6">{d.desc}</p>
                <a
                  href="#booking"
                  className="inline-block bg-plum text-white font-semibold px-7 py-3 rounded-full hover:bg-berry transition-colors text-sm shadow-md shadow-plum/25"
                >
                  {d.cta}
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ── About ─────────────────────────────────────────────────────
function AboutSection() {
  const stats = [
    { value: "5+", label: "Years Experience" },
    { value: "500+", label: "Happy Clients" },
    { value: "98%", label: "Satisfaction" },
  ];

  return (
    <section id="about" className="bg-cream py-24 px-6">
      <div className="max-w-6xl mx-auto grid lg:grid-cols-2 gap-16 items-center">
        {/* Photo collage */}
        <div className="relative h-[500px] sm:h-[560px]">
          <div className="absolute left-0 top-0 w-[56%] h-[70%] rounded-2xl overflow-hidden shadow-xl bg-blush">
            <img src={img("1761839256791-6a93f89fb8b0", 500, 600)} alt="Stylist at work" className="w-full h-full object-cover" />
          </div>
          <div className="absolute right-0 top-8 w-[41%] h-[46%] rounded-2xl overflow-hidden shadow-xl bg-blush-dark">
            <img src={img("1762745103094-6760fab8eb50", 400, 400)} alt="Finished wig install" className="w-full h-full object-cover" />
          </div>
          <div className="absolute left-8 bottom-0 w-[38%] h-[37%] rounded-2xl overflow-hidden shadow-xl bg-plum/20">
            <img src={img("1773904215697-e6c21fc27ac2", 380, 320)} alt="Salon interior" className="w-full h-full object-cover" />
          </div>
          <div className="absolute right-0 bottom-4 w-[41%] h-[40%] rounded-2xl overflow-hidden shadow-xl bg-blush">
            <img src={img("1527203561188-dae1bc1a417f", 400, 380)} alt="Braided style" className="w-full h-full object-cover" />
          </div>
          {/* Gold accent dot cluster */}
          <div
            className="absolute -bottom-4 left-1/2 -translate-x-1/2 bg-cream rounded-full px-4 py-2 shadow border border-gold/20"
          >
            <VanityBulbs count={5} />
          </div>
        </div>

        {/* Text side */}
        <div>
          <div className="flex items-center gap-3 mb-4">
            <span className="w-8 h-px bg-gold" />
            <span className="text-xs font-semibold tracking-widest uppercase text-berry">Our Story</span>
          </div>
          <h2 style={{ fontFamily: "var(--font-serif)" }} className="text-4xl sm:text-5xl text-ink mb-6 leading-tight">
            Your Journey to<br />
            <span className="italic text-berry">Effortless Style</span>
          </h2>
          <p className="text-ink/65 leading-relaxed mb-4">
            Friday Beauty was born from a simple belief: every woman deserves to feel extraordinary — every single day of the week. We started in Tanga as a small braiding studio and have grown into a full-service hair destination, trusted by hundreds of clients across the region.
          </p>
          <p className="text-ink/65 leading-relaxed mb-10">
            Our stylists combine technical precision with genuine artistry. Whether you walk in for a glueless install or a full wig revamp, you leave with more than great hair — you leave with confidence.
          </p>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 mb-10">
            {stats.map((s) => (
              <div key={s.label} className="text-center bg-blush rounded-2xl py-5 px-3">
                <p style={{ fontFamily: "var(--font-serif)" }} className="text-3xl text-plum">{s.value}</p>
                <p className="text-xs text-ink/55 mt-1 font-medium">{s.label}</p>
              </div>
            ))}
          </div>

          {/* Signature */}
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full overflow-hidden bg-blush-dark shadow">
              <img src={img("1616166183781-0fdd2ef83374", 100, 100)} alt="Founder" className="w-full h-full object-cover" />
            </div>
            <div>
              <p style={{ fontFamily: "var(--font-serif)" }} className="text-lg text-ink italic">Amina Saleh</p>
              <p className="text-xs text-ink/50 font-medium">Founder & Lead Stylist</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ── Gallery ───────────────────────────────────────────────────
const galleryItems = [
  { id: 1, label: "Lace Front Install", category: "Wigs" as const, price: "From TZS 45,000", img: "1762745103094-6760fab8eb50" },
  { id: 2, label: "Box Braids", category: "Braids" as const, price: "From TZS 35,000", img: "1527203561188-dae1bc1a417f" },
  { id: 3, label: "Wig Revamp — Dyed & Styled", category: "Revamps" as const, price: "From TZS 25,000", img: "1572955304332-bf714bd49add" },
  { id: 4, label: "Full Wig Customization", category: "Wigs" as const, price: "From TZS 60,000", img: "1762745103248-093916cce084" },
  { id: 5, label: "Knotless Braids", category: "Braids" as const, price: "From TZS 50,000", img: "1613099084406-4b9140fc780a" },
  { id: 6, label: "Glueless Wig Install", category: "Wigs" as const, price: "From TZS 40,000", img: "1770062422093-ae32c8fed2a3" },
  { id: 7, label: "Full Revamp — Cut & Curl", category: "Revamps" as const, price: "From TZS 30,000", img: "1739300293361-d1b503281902" },
  { id: 8, label: "Passion Twist", category: "Braids" as const, price: "From TZS 45,000", img: "1761839256840-7780a45b85dc" },
];

const galleryFilters = ["All", "Wigs", "Braids", "Revamps"] as const;
type GalleryFilter = (typeof galleryFilters)[number];

function GallerySection() {
  const [active, setActive] = useState<GalleryFilter>("All");

  const filtered = active === "All" ? galleryItems : galleryItems.filter((g) => g.category === active);

  return (
    <section id="gallery" className="bg-blush py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-3 justify-center mb-3">
          <span className="w-8 h-px bg-gold" />
          <span className="text-xs font-semibold tracking-widest uppercase text-berry">Our Work</span>
          <span className="w-8 h-px bg-gold" />
        </div>
        <h2 style={{ fontFamily: "var(--font-serif)" }} className="text-4xl sm:text-5xl text-ink text-center mb-10">
          Looks We Love
        </h2>

        {/* Filter tabs */}
        <div className="flex gap-2 justify-center flex-wrap mb-12">
          {galleryFilters.map((f) => (
            <button
              key={f}
              onClick={() => setActive(f)}
              className={`px-6 py-2.5 rounded-full text-sm font-semibold transition-all ${
                active === f
                  ? "bg-plum text-white shadow-md shadow-plum/30"
                  : "bg-white text-ink/60 hover:text-ink hover:bg-white/80 border border-blush-dark"
              }`}
            >
              {f}
            </button>
          ))}
        </div>

        {/* Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {filtered.map((item) => (
            <div key={item.id} className="group relative rounded-2xl overflow-hidden bg-blush-dark shadow hover:shadow-xl transition-shadow cursor-pointer">
              <div className="aspect-[3/4] overflow-hidden">
                <img
                  src={img(item.img, 400, 530)}
                  alt={item.label}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-ink/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-2 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all">
                <p className="text-white font-semibold text-sm leading-snug">{item.label}</p>
                <p className="text-gold-light text-xs mt-0.5">{item.price}</p>
              </div>
              {/* Category pill */}
              <span className="absolute top-3 left-3 bg-white/90 text-plum text-xs font-semibold px-3 py-1 rounded-full backdrop-blur-sm">
                {item.category}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ── Testimonials ──────────────────────────────────────────────
function Testimonials() {
  const reviews = [
    {
      name: "Zainab Kombo",
      location: "Tanga",
      quote: "I came in with a rough-looking wig I bought online and left with the most gorgeous, natural-looking install I have ever had. The attention to detail is unreal.",
      img: "1592520113018-180c8bc831c9",
      stars: 5,
    },
    {
      name: "Fatuma Ally",
      location: "Dar es Salaam",
      quote: "Drove two hours from DSM specifically for Friday Beauty. Worth every kilometre. My knotless braids lasted six full weeks and still looked fresh.",
      img: "1616166183781-0fdd2ef83374",
      stars: 5,
    },
    {
      name: "Neema Rashidi",
      location: "Tanga",
      quote: "Same-day booking, same-day install. I called at 10 AM and by 2 PM I was walking out with the most beautiful lace front I have ever owned. Truly incredible service.",
      img: "1613099084406-4b9140fc780a",
      stars: 5,
    },
  ];

  return (
    <section className="bg-cream py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <VanityBulbs count={9} className="mb-8" />
        <h2 style={{ fontFamily: "var(--font-serif)" }} className="text-4xl sm:text-5xl text-ink text-center mb-4">
          Client Love
        </h2>
        <p className="text-ink/50 text-center mb-16 max-w-sm mx-auto">Real words from real women who trusted us with their crown.</p>

        <div className="grid md:grid-cols-3 gap-6">
          {reviews.map((r) => (
            <div
              key={r.name}
              className="bg-white rounded-3xl p-8 shadow-md hover:shadow-lg transition-shadow border border-blush-dark/50"
            >
              <Stars n={r.stars} />
              <p className="text-ink/70 text-sm leading-relaxed my-5 italic">
                &ldquo;{r.quote}&rdquo;
              </p>
              <div className="flex items-center gap-3 pt-4 border-t border-blush">
                <div className="w-11 h-11 rounded-full overflow-hidden bg-blush flex-shrink-0">
                  <img src={img(r.img, 88, 88)} alt={r.name} className="w-full h-full object-cover" />
                </div>
                <div>
                  <p className="font-semibold text-ink text-sm">{r.name}</p>
                  <p className="text-ink/40 text-xs">{r.location}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ── Booking CTA ───────────────────────────────────────────────
function BookingCTA() {
  return (
    <section id="booking" className="bg-plum py-28 px-6 relative overflow-hidden">
      {/* Background bulb motif */}
      <div className="absolute top-8 left-1/2 -translate-x-1/2 opacity-30">
        <VanityBulbs count={15} />
      </div>
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 opacity-20">
        <VanityBulbs count={13} />
      </div>

      <div className="max-w-3xl mx-auto text-center relative z-10">
        <VanityBulbs count={9} className="mb-8" />
        <h2 style={{ fontFamily: "var(--font-serif)" }} className="text-5xl sm:text-6xl text-white mb-5 leading-tight">
          Ready for Your<br />
          <span className="text-gold italic">Friday?</span>
        </h2>
        <p className="text-white/60 text-lg mb-10 max-w-md mx-auto">
          Your next great hair day is one message away. Book instantly on WhatsApp.
        </p>

        <div className="flex flex-wrap gap-4 justify-center mb-16">
          <a
            href="https://wa.me/255712000000?text=Hi%20Friday%20Beauty%2C%20I%20would%20like%20to%20book%20an%20appointment."
            target="_blank"
            rel="noopener noreferrer"
            className="bg-gold text-ink font-bold px-9 py-4 rounded-full text-base hover:bg-gold-light transition-colors shadow-xl shadow-gold/20 flex items-center gap-3"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
            </svg>
            WhatsApp Us
          </a>
          <a href="tel:+255712000000" className="border-2 border-white/30 text-white font-semibold px-8 py-4 rounded-full hover:bg-white/10 transition-colors">
            Call Us
          </a>
        </div>

        {/* Contact info */}
        <div className="grid sm:grid-cols-3 gap-6 max-w-2xl mx-auto">
          {[
            { icon: "📍", label: "Location", value: "Tanga, Tanzania" },
            { icon: "📞", label: "Phone", value: "+255 712 000 000" },
            { icon: "📸", label: "Instagram", value: "@fridaybeautytanga" },
          ].map((c) => (
            <div key={c.label} className="text-center">
              <p className="text-2xl mb-1">{c.icon}</p>
              <p className="text-white/40 text-xs font-medium uppercase tracking-wider mb-1">{c.label}</p>
              <p className="text-white/80 text-sm font-medium">{c.value}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ── Footer ─────────────────────────────────────────────────────
function Footer() {
  const links = ["Services", "About", "Gallery"];
  return (
    <footer className="bg-ink text-white/60 py-12 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-8 mb-10">
          {/* Logo */}
          <a href="#" className="flex items-center gap-2.5">
            <span className="flex gap-1 items-center">
              {[8, 11, 8].map((s, i) => (
                <span key={i} style={{ display: "block", width: s, height: s, borderRadius: "50%", background: "#C9973A", boxShadow: "0 0 6px 2px rgba(201,151,58,0.4)" }} />
              ))}
            </span>
            <span style={{ fontFamily: "var(--font-serif)" }} className="text-lg text-white tracking-wide">
              Friday<span className="text-gold italic"> Beauty</span>
            </span>
          </a>

          {/* Nav links */}
          <nav className="flex gap-6">
            {links.map((l) => (
              <a key={l} href={`#${l.toLowerCase()}`} className="text-sm hover:text-white transition-colors">
                {l}
              </a>
            ))}
            <a href="#booking" className="text-sm hover:text-white transition-colors">Book Now</a>
          </nav>

          {/* Social icons */}
          <div className="flex gap-3">
            {/* Instagram */}
            <a
              href="https://instagram.com/fridaybeautytanga"
              target="_blank"
              rel="noopener noreferrer"
              className="w-9 h-9 rounded-full border border-white/20 flex items-center justify-center hover:border-gold hover:text-gold transition-colors"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}>
                <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
                <circle cx="12" cy="12" r="4" />
                <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
              </svg>
            </a>
            {/* WhatsApp */}
            <a
              href="https://wa.me/255712000000"
              target="_blank"
              rel="noopener noreferrer"
              className="w-9 h-9 rounded-full border border-white/20 flex items-center justify-center hover:border-gold hover:text-gold transition-colors"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
              </svg>
            </a>
            {/* TikTok */}
            <a
              href="#"
              className="w-9 h-9 rounded-full border border-white/20 flex items-center justify-center hover:border-gold hover:text-gold transition-colors"
            >
              <svg width="14" height="16" viewBox="0 0 24 24" fill="currentColor">
                <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1V9.01a6.33 6.33 0 00-.79-.05 6.34 6.34 0 00-6.34 6.34 6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.33-6.34V8.69a8.18 8.18 0 004.78 1.52V6.75a4.86 4.86 0 01-1.01-.06z" />
              </svg>
            </a>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-white/10 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-white/30">
            &copy; {new Date().getFullYear()} Friday Beauty Salon. All rights reserved. Tanga, Tanzania.
          </p>
          <VanityBulbs count={5} />
        </div>
      </div>
    </footer>
  );
}

// ── App ────────────────────────────────────────────────────────
export default function App() {
  return (
    <div className="min-h-screen font-sans">
      <Nav />
      <HeroSection />
      <MarqueeStrip />
      <ServiceCategories />
      <FeaturedDeals />
      <AboutSection />
      <GallerySection />
      <Testimonials />
      <BookingCTA />
      <Footer />
    </div>
  );
}
